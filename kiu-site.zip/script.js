const menuBtn = document.getElementById("menuBtn");
const mobileMenu = document.getElementById("mobileMenu");
const closeMenu = document.getElementById("closeMenu");

menuBtn.addEventListener("click", () => {
    mobileMenu.classList.add("active");
    document.body.style.overflow = "hidden";
});

closeMenu.addEventListener("click", () => {
    mobileMenu.classList.remove("active");
    document.body.style.overflow = "";
});

document.querySelectorAll(".mobile-menu a").forEach(link => {
    link.addEventListener("click", () => {
        mobileMenu.classList.remove("active");
        document.body.style.overflow = "";
    });
});

document.querySelectorAll(".program-card").forEach(card => {
    card.addEventListener("mouseenter", () => {
        document.querySelectorAll(".program-card").forEach(item => {
            item.classList.remove("active");
        });
        card.classList.add("active");
    });
});

const revealItems = document.querySelectorAll(".intro, .program-card, .campus-content, .admissions, .quote");

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("visible");
        }
    });
}, { threshold: 0.12 });

revealItems.forEach(item => observer.observe(item));
