const movies = [
    {
        id:1,title:"The Last Light",genre:"Drama",year:2026,rating:9.1,runtime:"2h 08m",
        description:"After a mysterious blackout covers half the world, a former radio engineer crosses a silent country searching for the last working transmitter.",
        color:"linear-gradient(145deg,#17191e,#b27b35 48%,#241514)"
    },
    {
        id:2,title:"Neon Run",genre:"Action",year:2026,rating:8.7,runtime:"1h 54m",
        description:"A courier with one night to escape a city controlled by private security races through neon streets with a package that everyone wants.",
        color:"linear-gradient(145deg,#101b32,#e24d68 48%,#11131e)"
    },
    {
        id:3,title:"Orbit 9",genre:"Sci-Fi",year:2025,rating:8.9,runtime:"2h 16m",
        description:"A deep-space crew receives a signal from a planet believed to be empty, forcing them to question why humanity was invited there.",
        color:"linear-gradient(145deg,#081321,#286b91 48%,#090a12)"
    },
    {
        id:4,title:"After Sunday",genre:"Comedy",year:2026,rating:8.2,runtime:"1h 42m",
        description:"Three friends make a ridiculous pact to change their lives before Monday morning and accidentally create the worst weekend of their lives.",
        color:"linear-gradient(145deg,#332313,#e4a72d 50%,#682f20)"
    },
    {
        id:5,title:"Cold Room",genre:"Horror",year:2025,rating:8.5,runtime:"1h 48m",
        description:"A night-shift archivist discovers a room that appears on no blueprint and contains recordings of events that have not happened yet.",
        color:"linear-gradient(145deg,#0a1011,#416b68 45%,#111719)"
    },
    {
        id:6,title:"The Witness",genre:"Thriller",year:2026,rating:8.8,runtime:"2h 01m",
        description:"A witness to a city-wide conspiracy disappears hours before trial, leaving one detective with a single photograph.",
        color:"linear-gradient(145deg,#20120f,#a33e31 50%,#090b10)"
    },
    {
        id:7,title:"Blue Hour",genre:"Drama",year:2025,rating:8.4,runtime:"1h 57m",
        description:"Two strangers meet every evening at the same train platform and slowly discover that their lives are connected by an old photograph.",
        color:"linear-gradient(145deg,#101b2d,#526b9c 55%,#111522)"
    },
    {
        id:8,title:"Zero Point",genre:"Action",year:2025,rating:8.1,runtime:"2h 05m",
        description:"An ex-pilot is recruited for one impossible mission: reach a mountain facility before an automated defense system wakes up.",
        color:"linear-gradient(145deg,#171717,#8b3830 50%,#282018)"
    },
    {
        id:9,title:"Static",genre:"Sci-Fi",year:2024,rating:8.6,runtime:"1h 51m",
        description:"A student building a radio telescope accidentally records a transmission that appears to be coming from thirty years in the future.",
        color:"linear-gradient(145deg,#111329,#7656ad 48%,#161126)"
    },
    {
        id:10,title:"Small Things",genre:"Comedy",year:2024,rating:7.9,runtime:"1h 38m",
        description:"A perfectionist designer loses everything in one day and discovers that starting over is much stranger than expected.",
        color:"linear-gradient(145deg,#33231a,#c77d48 48%,#282018)"
    },
    {
        id:11,title:"Black Water",genre:"Horror",year:2024,rating:8.0,runtime:"1h 46m",
        description:"A coastal town wakes to find the ocean completely still, while something beneath the surface begins calling people by name.",
        color:"linear-gradient(145deg,#080f14,#245765 50%,#090c10)"
    },
    {
        id:12,title:"Deadline",genre:"Thriller",year:2026,rating:8.3,runtime:"1h 52m",
        description:"A journalist receives an anonymous file predicting tomorrow's biggest crime and must decide whether exposing it will cause it.",
        color:"linear-gradient(145deg,#171113,#7c303b 48%,#0c0d11)"
    }
];

let favorites=JSON.parse(localStorage.getItem("cinevaFavorites"))||[];
let activeGenre="all";
let selectedMovie=null;

const grid=document.getElementById("movieGrid");
const trending=document.getElementById("trendingMovies");
const search=document.getElementById("search");
const sort=document.getElementById("sort");
const modalOverlay=document.getElementById("modalOverlay");

function card(movie){
    const isFavorite=favorites.includes(movie.id);

    return `
    <article class="movie-card" data-id="${movie.id}">
        <div class="movie-poster" style="--poster:${movie.color}">
            <span class="poster-number">${String(movie.id).padStart(2,"0")}</span>
            <div class="rating"><span>★</span> ${movie.rating}</div>
        </div>
        <div class="movie-info">
            <p>${movie.genre}</p>
            <h3>${movie.title}</h3>
            <div class="movie-meta">
                <span>${movie.year}</span>
                <span>${movie.runtime}</span>
                <span>${isFavorite?"♥":"♡"}</span>
            </div>
        </div>
    </article>`;
}

function renderMovies(){
    const query=search.value.toLowerCase();

    let list=movies.filter(movie=>{
        const genreMatch=activeGenre==="all"||movie.genre===activeGenre;
        const searchMatch=movie.title.toLowerCase().includes(query);
        return genreMatch&&searchMatch;
    });

    if(sort.value==="rating")list.sort((a,b)=>b.rating-a.rating);
    if(sort.value==="year")list.sort((a,b)=>b.year-a.year);
    if(sort.value==="title")list.sort((a,b)=>a.title.localeCompare(b.title));

    grid.innerHTML=list.map(card).join("");

    document.querySelectorAll(".movie-card").forEach(item=>{
        item.addEventListener("click",()=>openMovie(Number(item.dataset.id)));
    });

    updateFavoriteCount();
}

function renderTrending(){
    const list=[...movies].sort((a,b)=>b.rating-a.rating).slice(0,4);
    trending.innerHTML=list.map(card).join("");

    trending.querySelectorAll(".movie-card").forEach(item=>{
        item.addEventListener("click",()=>openMovie(Number(item.dataset.id)));
    });
}

function openMovie(id){
    selectedMovie=movies.find(movie=>movie.id===id);
    if(!selectedMovie)return;

    document.getElementById("modalTitle").textContent=selectedMovie.title;
    document.getElementById("modalGenre").textContent=selectedMovie.genre;
    document.getElementById("modalYear").textContent=selectedMovie.year;
    document.getElementById("modalRuntime").textContent=selectedMovie.runtime;
    document.getElementById("modalRating").textContent=selectedMovie.rating;
    document.getElementById("modalDescription").textContent=selectedMovie.description;
    document.getElementById("modalArt").style.setProperty("--modal-color",selectedMovie.color);

    updateFavoriteButton();

    modalOverlay.classList.add("active");
    document.body.style.overflow="hidden";
}

function closeMovie(){
    modalOverlay.classList.remove("active");
    document.body.style.overflow="";
}

function updateFavoriteButton(){
    const button=document.getElementById("favoriteModal");
    const saved=favorites.includes(selectedMovie.id);

    button.textContent=saved?"♥ Remove from favorites":"♡ Add to favorites";
}

function toggleFavorite(){
    if(!selectedMovie)return;

    if(favorites.includes(selectedMovie.id)){
        favorites=favorites.filter(id=>id!==selectedMovie.id);
    }else{
        favorites.push(selectedMovie.id);
    }

    localStorage.setItem("cinevaFavorites",JSON.stringify(favorites));
    updateFavoriteButton();
    renderMovies();
    renderTrending();
}

function updateFavoriteCount(){
    document.getElementById("favoriteCount").textContent=favorites.length;
}

document.querySelectorAll(".genre").forEach(button=>{
    button.addEventListener("click",()=>{
        document.querySelectorAll(".genre").forEach(item=>item.classList.remove("active"));
        button.classList.add("active");
        activeGenre=button.dataset.genre;
        renderMovies();
        document.getElementById("movies").scrollIntoView({behavior:"smooth"});
    });
});

search.addEventListener("input",renderMovies);
sort.addEventListener("change",renderMovies);

document.getElementById("modalClose").addEventListener("click",closeMovie);
modalOverlay.addEventListener("click",event=>{
    if(event.target===modalOverlay)closeMovie();
});

document.getElementById("favoriteModal").addEventListener("click",toggleFavorite);

document.getElementById("heroDetails").addEventListener("click",()=>{
    openMovie(1);
});

document.getElementById("trailerBtn").addEventListener("click",()=>{
    alert("Trailer player coming soon.");
});

document.getElementById("trendingBtn").addEventListener("click",()=>{
    activeGenre="all";
    document.querySelectorAll(".genre").forEach(item=>item.classList.remove("active"));
    document.querySelector('[data-genre="all"]').classList.add("active");
    renderMovies();
    document.getElementById("movies").scrollIntoView({behavior:"smooth"});
});

document.getElementById("favoritesBtn").addEventListener("click",()=>{
    if(favorites.length===0){
        alert("You have no favorite movies yet.");
        return;
    }

    const favoriteMovies=movies.filter(movie=>favorites.includes(movie.id));

    grid.innerHTML=favoriteMovies.map(card).join("");

    document.querySelectorAll(".movie-card").forEach(item=>{
        item.addEventListener("click",()=>openMovie(Number(item.dataset.id)));
    });

    document.getElementById("movies").scrollIntoView({behavior:"smooth"});
});

document.addEventListener("keydown",event=>{
    if(event.key==="Escape")closeMovie();
});

renderTrending();
renderMovies();
