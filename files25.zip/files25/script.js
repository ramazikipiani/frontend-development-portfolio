// Scroll-reveal for sections
document.addEventListener('DOMContentLoaded', () => {
  const revealTargets = document.querySelectorAll('.step, .feature-card, .price-card, .section-title, .section-eyebrow');
  revealTargets.forEach(el => el.classList.add('reveal'));

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealTargets.forEach(el => observer.observe(el));

  // Hero checklist demo: cycle the "active" task to simulate clearing the list
  const checklist = document.getElementById('checklist');
  if (checklist) {
    const tasks = Array.from(checklist.querySelectorAll('.task'));
    let activeIndex = tasks.findIndex(t => t.dataset.status === 'active');

    setInterval(() => {
      if (activeIndex === -1 || activeIndex >= tasks.length) return;

      // clear current active task
      tasks[activeIndex].dataset.status = 'cleared';
      tasks[activeIndex].querySelector('.tick').textContent = '✓';

      // activate next pending task, if any
      const nextIndex = tasks.findIndex((t, i) => i > activeIndex && t.dataset.status === 'pending');
      if (nextIndex !== -1) {
        tasks[nextIndex].dataset.status = 'active';
        tasks[nextIndex].querySelector('.tick').textContent = '•';
        activeIndex = nextIndex;
      } else {
        // all cleared — reset the demo after a pause
        activeIndex = tasks.length;
        setTimeout(() => {
          tasks.forEach((t, i) => {
            if (i < 2) {
              t.dataset.status = 'cleared';
              t.querySelector('.tick').textContent = '✓';
            } else if (i === 2) {
              t.dataset.status = 'active';
              t.querySelector('.tick').textContent = '•';
            } else {
              t.dataset.status = 'pending';
              t.querySelector('.tick').textContent = '·';
            }
          });
          activeIndex = 2;
        }, 1800);
      }
    }, 2600);
  }

  // CTA form
  const form = document.getElementById('ctaForm');
  const note = document.getElementById('ctaNote');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = form.querySelector('input[type="email"]').value.trim();
      if (email) {
        note.textContent = "You're cleared for takeoff. Check your inbox.";
        form.reset();
      }
    });
  }
});
