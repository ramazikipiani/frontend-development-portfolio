// popup doesn't need much, instructions are in html
