// when user opens a pdf, send them to our viewer page
// chrome built-in pdf viewer can't be changed by extensions so we use pdf.js

const VIEWER = 'pdf-viewer.html';
const CHROME_PDF_ID = 'mhjfbmdgcfjbbpaeojofohoefgiehjai';

function getViewerUrl(pdfUrl) {
  return chrome.runtime.getURL(VIEWER + '?file=' + encodeURIComponent(pdfUrl));
}

function isPdf(url) {
  if (!url || url.includes(VIEWER)) return false;
  try {
    const u = new URL(url);
    if (u.pathname.toLowerCase().endsWith('.pdf')) return true;
  } catch (e) {}
  return false;
}

function getPdfFromChromeViewer(url) {
  if (!url.includes(CHROME_PDF_ID)) return null;
  try {
    const u = new URL(url);
    const f = u.searchParams.get('file');
    return f ? decodeURIComponent(f) : null;
  } catch (e) {
    return null;
  }
}

function shouldRedirect(url) {
  if (!url || url.includes(VIEWER)) return null;
  if (isPdf(url)) return getViewerUrl(url);
  const fromChrome = getPdfFromChromeViewer(url);
  if (fromChrome) return getViewerUrl(fromChrome);
  return null;
}

function redirect(tabId, url) {
  const target = shouldRedirect(url);
  if (target) {
    chrome.tabs.update(tabId, { url: target });
  }
}

chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (d.frameId === 0) redirect(d.tabId, d.url);
});

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'loading' && tab.url) {
    redirect(tabId, tab.url);
  }
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'openPdf' && sender.tab) {
    redirect(sender.tab.id, msg.url);
  }
});
