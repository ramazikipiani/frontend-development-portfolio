// backup - tell background to open pdf in our viewer
if (location.pathname.toLowerCase().endsWith('.pdf')) {
  chrome.runtime.sendMessage({ type: 'openPdf', url: location.href });
}
