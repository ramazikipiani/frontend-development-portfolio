import * as pdfjs from './pdfjs/pdf.mjs';
import { Util } from './pdfjs/pdf.mjs';

pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('pdfjs/pdf.worker.mjs');

// --- variables ---
let pdfDoc = null;
let sentences = [];
let currentIdx = 0;
let scale = 1.5;
let pdfUrl = '';
let highlightEls = [];

const pagesDiv = document.getElementById('pages');
const loadingDiv = document.getElementById('loading');
const errorDiv = document.getElementById('error');
const errorMsg = document.getElementById('error-msg');
const fileNameEl = document.getElementById('file-name');
const infoEl = document.getElementById('info');
const readingBox = document.getElementById('reading-box');
const readingText = document.getElementById('reading-text');

// --- start ---
const params = new URLSearchParams(location.search);
pdfUrl = decodeURIComponent(params.get('file') || '');

if (!pdfUrl) {
  showError('No PDF file in URL');
} else {
  loadPdf(pdfUrl);
}

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Tab') return;
  e.preventDefault();
  if (e.shiftKey) goPrev();
  else goNext();
});

document.getElementById('zoom-in').onclick = () => { scale += 0.2; loadPdf(pdfUrl); };
document.getElementById('zoom-out').onclick = () => { scale = Math.max(0.6, scale - 0.2); loadPdf(pdfUrl); };

// --- load pdf ---
async function loadPdf(url) {
  loadingDiv.hidden = false;
  errorDiv.hidden = true;
  pagesDiv.innerHTML = '';
  clearHighlight();

  try {
    pdfDoc = await pdfjs.getDocument({ url }).promise;
    fileNameEl.textContent = pdfDoc.info?.Title || url.split('/').pop() || 'PDF';

    const pageDataList = [];
    for (let p = 1; p <= pdfDoc.numPages; p++) {
      pageDataList.push(await renderPage(p));
    }

    sentences = makeSentenceList(pageDataList);
    const saved = currentIdx;
    currentIdx = sentences.length ? Math.min(saved, sentences.length - 1) : 0;
    if (sentences.length > 0) showSentence(currentIdx);

    loadingDiv.hidden = true;
  } catch (err) {
    showError(err.message || 'Failed to load');
  }
}

async function renderPage(pageNum) {
  const page = await pdfDoc.getPage(pageNum);
  const viewport = page.getViewport({ scale });
  const textContent = await page.getTextContent();

  const wrap = document.createElement('div');
  wrap.className = 'page';
  wrap.dataset.page = pageNum;

  const surface = document.createElement('div');
  surface.className = 'page-inner';
  surface.style.width = viewport.width + 'px';
  surface.style.height = viewport.height + 'px';

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  canvas.width = viewport.width * dpr;
  canvas.height = viewport.height * dpr;
  canvas.style.width = viewport.width + 'px';
  canvas.style.height = viewport.height + 'px';
  ctx.scale(dpr, dpr);
  await page.render({ canvasContext: ctx, viewport }).promise;

  const hlLayer = document.createElement('div');
  hlLayer.className = 'hl-layer';

  surface.appendChild(canvas);
  surface.appendChild(hlLayer);
  wrap.appendChild(surface);
  pagesDiv.appendChild(wrap);

  const { text, parts } = getTextFromPage(textContent.items, viewport);
  return { pageNum, text, parts };
}

// --- text + sentences ---
function getTextRect(item, viewport) {
  const t = Util.transform(viewport.transform, item.transform);
  const h = Math.hypot(t[2], t[3]);
  return {
    left: t[4],
    top: t[5] - h,
    width: Math.abs(item.width * viewport.scale),
    height: item.height ? Math.abs(item.height * viewport.scale) : h,
  };
}

function getTextFromPage(items, viewport) {
  // sort top to bottom (pdf text order is messy)
  const sorted = items
    .filter((i) => i.str && i.str.trim())
    .map((i) => ({ item: i, rect: getTextRect(i, viewport) }))
    .sort((a, b) => {
      if (Math.abs(a.rect.top - b.rect.top) > 8) return a.rect.top - b.rect.top;
      return a.rect.left - b.rect.left;
    });

  let text = '';
  const parts = [];
  let lastRect = null;

  for (const { item, rect } of sorted) {
    if (text.length > 0 && lastRect) {
      if (Math.abs(rect.top - lastRect.top) > 8) {
        text += '\n';
      } else if (rect.left - (lastRect.left + lastRect.width) > 2) {
        text += ' ';
      }
    }
    const start = text.length;
    text += item.str;
    parts.push({ start, end: text.length, rect });
    lastRect = rect;
  }

  const trimStart = text.length - text.trimStart().length;
  text = text.trim();
  const fixedParts = parts
    .map((p) => ({ ...p, start: p.start - trimStart, end: p.end - trimStart }))
    .filter((p) => p.end > 0 && p.start < text.length);

  return { text, parts: fixedParts };
}

function splitSentences(text) {
  const result = [];
  let i = 0;
  while (i < text.length) {
    while (i < text.length && /[\s\n]/.test(text[i])) i++;
    if (i >= text.length) break;
    const start = i;
    while (i < text.length) {
      if (/[.!?]/.test(text[i])) { i++; break; }
      if (text[i] === '\n') break;
      i++;
    }
    const s = text.slice(start, i).trim();
    if (s) {
      const pos = text.indexOf(s, start);
      result.push({ text: s, start: pos, end: pos + s.length });
    }
  }
  return result;
}

function makeSentenceList(pageDataList) {
  const list = [];
  for (const page of pageDataList) {
    for (const s of splitSentences(page.text)) {
      const rects = [];
      for (const p of page.parts) {
        if (p.end > s.start && p.start < s.end) rects.push(p.rect);
      }
      if (rects.length) {
        list.push({ pageNum: page.pageNum, text: s.text, rects });
      }
    }
  }
  return list;
}

// --- navigation ---
function goNext() {
  if (currentIdx < sentences.length - 1) {
    currentIdx++;
    showSentence(currentIdx);
  }
}

function goPrev() {
  if (currentIdx > 0) {
    currentIdx--;
    showSentence(currentIdx);
  }
}

function showSentence(idx) {
  clearHighlight();
  const s = sentences[idx];
  if (!s) return;

  const page = pagesDiv.querySelector('[data-page="' + s.pageNum + '"]');
  const layer = page?.querySelector('.hl-layer');
  if (!layer) return;

  const tilts = [-0.8, 0.5, -0.4];
  s.rects.forEach((r, n) => {
    const el = document.createElement('div');
    el.className = 'marker';
    el.dataset.line = n % 3;
    el.style.left = (r.left - 4) + 'px';
    el.style.top = (r.top - 3) + 'px';
    el.style.width = (r.width + 8) + 'px';
    el.style.height = (r.height + 6) + 'px';
    el.style.transform = 'rotate(' + tilts[n % 3] + 'deg)';
    layer.appendChild(el);
    highlightEls.push(el);
  });

  infoEl.textContent = 'Sentence ' + (idx + 1) + ' / ' + sentences.length;
  readingText.textContent = s.text;
  readingBox.hidden = false;

  // scroll to sentence
  const first = s.rects[0];
  const y = page.offsetTop + first.top - 100;
  window.scrollTo({ top: y, behavior: 'smooth' });
}

function clearHighlight() {
  highlightEls.forEach((el) => el.remove());
  highlightEls = [];
}

function showError(msg) {
  loadingDiv.hidden = true;
  errorDiv.hidden = false;
  errorMsg.textContent = msg;
}
