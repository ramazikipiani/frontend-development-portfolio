# PDF Sentence Navigator

Chrome Extension homework - Extension 2026

## რას აკეთებს / What it does

- **Tab** - შემდეგ წინადადებაზე გადასვლა (next sentence)
- **Shift+Tab** - წინა წინადადებაზე დაბრუნება (previous sentence)
- აქტიური წინადადება ნათლდება marker-ით (highlights like a pen)

ყველაფერი ლოკალურად მუშაობს, არაფერი არ იგზავნება სერვერზე.

## ფაილების სტრუქტურა

```
pdf-sentence-navigator/
├── manifest.json       - extension config
├── background.js       - opens pdf in our viewer
├── content.js          - helps detect pdf pages
├── popup.html/js/css   - small popup with instructions
├── pdf-viewer.html     - main page where pdf is shown
├── pdf-viewer.js       - pdf.js + sentence logic + tab keys
├── viewer.css          - styles
├── pdfjs/              - pdf.js library (from mozilla)
│   ├── pdf.mjs
│   └── pdf.worker.mjs
└── img/                - icons
```

## როგორ ჩავტვირთო Chrome-ში

1. გახსენი `chrome://extensions`
2. ჩართე **Developer mode**
3. დააჭირე **Load unpacked**
4. აირჩიე ეს ფოლდერი

## ლოკალური PDF ფაილებისთვის

extensions გვერდზე ჩართე **Allow access to file URLs**

## როგორ შევამოწმო

1. გახსენი რაიმე PDF (მაგ. ჩამოტვირთე ან გახსენი ლინკი)
2. უნდა გაიხსნას ჩვენი viewer-ით
3. დააჭირე Tab - წინადადება გამოიყურება

## შენიშვნა

Chrome-ის ჩაშენებულ PDF viewer-ში extension-ით ვერ ვცვლით DOM-ს, ამიტომ გამოვიყენე PDF.js ბიბლიოთეკა.

## ბიბლიოთეკა

PDF.js უკვე არის `pdfjs/` ფოლდერში. თავიდან ჩასაწერად შეიძლება ჩამოტვირთო https://mozilla.github.io/pdf.js/
