const products = [
{id:1,name:"Studio Headphones",category:"tech",price:149,color:"#d9c6ff"},
{id:2,name:"Minimal Backpack",category:"fashion",price:89,color:"#d7a46e"},
{id:3,name:"Desk Lamp",category:"home",price:74,color:"#e7e2a2"},
{id:4,name:"Wireless Speaker",category:"tech",price:119,color:"#91b8c7"},
{id:5,name:"Classic Sneakers",category:"fashion",price:129,color:"#e8e8e8"},
{id:6,name:"Ceramic Set",category:"home",price:54,color:"#c69b87"},
{id:7,name:"Smart Watch",category:"tech",price:199,color:"#969696"},
{id:8,name:"Cotton Overshirt",category:"fashion",price:79,color:"#a9b79b"},
{id:9,name:"Table Organizer",category:"home",price:39,color:"#d2b48c"}
];

let cart=JSON.parse(localStorage.getItem("novaCart"))||[];
let currentCategory="all";

const productsContainer=document.getElementById("products");
const cartItems=document.getElementById("cartItems");
const cartTotal=document.getElementById("cartTotal");
const cartCount=document.getElementById("cartCount");
const cartElement=document.getElementById("cart");
const cartOverlay=document.getElementById("cartOverlay");

function renderProducts(){
const search=document.getElementById("searchInput").value.toLowerCase();
const sort=document.getElementById("sortSelect").value;

let filtered=products.filter(product=>{
const categoryMatch=currentCategory==="all"||product.category===currentCategory;
const searchMatch=product.name.toLowerCase().includes(search);
return categoryMatch&&searchMatch;
});

if(sort==="low")filtered.sort((a,b)=>a.price-b.price);
if(sort==="high")filtered.sort((a,b)=>b.price-a.price);
if(sort==="name")filtered.sort((a,b)=>a.name.localeCompare(b.name));

productsContainer.innerHTML=filtered.map(product=>`
<article class="product-card">
<div class="product-image" style="--product-color:${product.color}"></div>
<div class="product-info">
<span class="product-category">${product.category}</span>
<h3>${product.name}</h3>
<div class="product-bottom">
<span class="price">$${product.price.toFixed(2)}</span>
<button class="add-btn" onclick="addToCart(${product.id})">Add to cart</button>
</div>
</div>
</article>`).join("");
}

function addToCart(id){
const existing=cart.find(item=>item.id===id);
if(existing)existing.quantity++;
else cart.push({id,quantity:1});
saveCart();
renderCart();
openCart();
}

function removeFromCart(id){
cart=cart.filter(item=>item.id!==id);
saveCart();
renderCart();
}

function changeQuantity(id,amount){
const item=cart.find(item=>item.id===id);
if(!item)return;
item.quantity+=amount;
if(item.quantity<=0){removeFromCart(id);return;}
saveCart();
renderCart();
}

function renderCart(){
if(cart.length===0){
cartItems.innerHTML='<div class="empty-cart"><p>Your cart is empty.</p></div>';
cartTotal.textContent="$0.00";
cartCount.textContent="0";
return;
}

let total=0,count=0;

cartItems.innerHTML=cart.map(item=>{
const product=products.find(product=>product.id===item.id);
const itemTotal=product.price*item.quantity;
total+=itemTotal;
count+=item.quantity;

return `
<div class="cart-item">
<div class="cart-item-image" style="--product-color:${product.color}"></div>
<div>
<h4>${product.name}</h4>
<p>$${product.price.toFixed(2)} × ${item.quantity}</p>
<div>
<button onclick="changeQuantity(${product.id},-1)">−</button>
<span>${item.quantity}</span>
<button onclick="changeQuantity(${product.id},1)">+</button>
</div>
</div>
<div>
<strong>$${itemTotal.toFixed(2)}</strong>
<button class="remove-item" onclick="removeFromCart(${product.id})">Remove</button>
</div>
</div>`;
}).join("");

cartTotal.textContent=`$${total.toFixed(2)}`;
cartCount.textContent=count;
}

function saveCart(){
localStorage.setItem("novaCart",JSON.stringify(cart));
}

function openCart(){
cartElement.classList.add("active");
cartOverlay.classList.add("active");
document.body.style.overflow="hidden";
}

function closeCart(){
cartElement.classList.remove("active");
cartOverlay.classList.remove("active");
document.body.style.overflow="";
}

document.querySelectorAll(".category-card").forEach(button=>{
button.addEventListener("click",()=>{
document.querySelectorAll(".category-card").forEach(item=>item.classList.remove("active"));
button.classList.add("active");
currentCategory=button.dataset.category;
renderProducts();
});
});

document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("sortSelect").addEventListener("change",renderProducts);
document.getElementById("cartBtn").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
cartOverlay.addEventListener("click",closeCart);

document.getElementById("checkoutBtn").addEventListener("click",()=>{
if(cart.length===0){alert("Your cart is empty.");return;}
alert("Thank you for your order!");
cart=[];
saveCart();
renderCart();
closeCart();
});

document.getElementById("discountBtn").addEventListener("click",()=>{
navigator.clipboard?.writeText("NOVA10");
alert("Discount code NOVA10 copied!");
});

document.getElementById("newsletterForm").addEventListener("submit",event=>{
event.preventDefault();
const email=document.getElementById("emailInput").value;
const message=document.getElementById("newsletterMessage");
if(email){
message.textContent="You're on the list.";
event.target.reset();
}
});

renderProducts();
renderCart();
